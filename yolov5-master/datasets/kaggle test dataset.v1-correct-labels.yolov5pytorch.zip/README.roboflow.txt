
kaggle test dataset - v1 correct labels
==============================

This dataset was exported via roboflow.ai on January 17, 2022 at 10:31 AM GMT

It includes 848 images.
Masks are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


